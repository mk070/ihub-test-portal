from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import traceback
from pymongo import MongoClient
import os

# Update the MongoClient to use the provided connection string
client = MongoClient("mongodb+srv://ihub:ihub@test-portal.lcgyx.mongodb.net/test_portal_db?retryWrites=true&w=majority")
db = client["test_portal_db"]  # Ensure this matches the database name in your connection string
questions_collection = db['Questions_Library']
temp_questions_collection = db['tempQuestions']
final_questions_collection = db['finalQuestions']

PROBLEMS_FILE_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'Frontend', 'public', 'json', 'questions.json')

@csrf_exempt
def fetch_questions(request):
    """
    Fetches questions from `Questions_Library`. If `Questions_Library` is empty, it returns an empty list.
    """
    try:
        # Fetch questions from `Questions_Library`
        documents = questions_library_collection.find({}, {'problems': 1, '_id': 0})
        problems = [problem for document in documents for problem in document.get('problems', [])]
        return JsonResponse({'problems': problems}, status=200)
    except Exception as e:
        print("Error fetching questions:", str(e))
        traceback.print_exc()
        return JsonResponse({'error': 'Failed to fetch questions'}, status=500)


@csrf_exempt
def save_problem_data(new_problem):
    """
    Adds a new problem to the problems array in `Questions_Library`. If the collection is empty,
    it creates a new document with the problem.
    """
    try:
        problem_data = {
            "id": new_problem.get('id'),
            "title": new_problem.get('title', ''),
            "role": new_problem.get('role', []),
            "level": new_problem.get('level', ''),
            "problem_statement": new_problem.get('problem_statement', ''),
            "samples": new_problem.get('samples', []),
            "hidden_samples": new_problem.get('hidden_samples', [])
        }

        # Check if there is at least one document in Questions_Library
        if questions_library_collection.count_documents({}) == 0:
            # Create a new document with the problem
            questions_library_collection.insert_one({"problems": [problem_data]})
            message = 'New document created and problem added!'
        else:
            # Append new problem to the first document
            questions_library_collection.update_one(
                {}, {'$push': {'problems': problem_data}}
            )
            message = 'Problem added to existing document!'

        return JsonResponse({'message': message, 'problem_id': problem_data['id']}, status=201)

    except Exception as e:
        print("Error saving problem data:", str(e))
        traceback.print_exc()
        return JsonResponse({'error': 'Failed to save problem data'}, status=500)


@csrf_exempt
def publish_questions(request):
    """
    Moves questions from `Questions_Library` to `finalQuestions` with the contestId and visible_to.
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            contest_id = data.get('contestId')
            visible_to = data.get('students', [])

            if not contest_id:
                return JsonResponse({'error': 'contestId is missing in the request'}, status=400)

            # Fetch questions from `Questions_Library`
            documents = questions_library_collection.find({}, {'problems': 1, '_id': 0})
            all_problems = [problem for document in documents for problem in document.get('problems', [])]

            # Check if a document with the same contestId exists in finalQuestions
            existing_document = final_questions_collection.find_one({"contestId": contest_id})

            if existing_document:
                # Append problems to the existing document
                final_questions_collection.update_one(
                    {"contestId": contest_id},
                    {'$push': {'problems': {'$each': all_problems}}}
                )
                message = 'Questions appended to existing contest!'
            else:
                # Insert a new document with contestId, problems array, and visible_to
                final_questions_collection.insert_one({
                    "contestId": contest_id,
                    "problems": all_problems,
                    "visible_to": visible_to
                })
                message = 'Questions published successfully!'

            return JsonResponse({'message': message}, status=200)

        except Exception as e:
            print("Error publishing questions:", str(e))
            traceback.print_exc()
            return JsonResponse({'error': 'Failed to publish questions'}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)


@csrf_exempt
def modify_problem_data(new_problem):
    """
    Modifies an existing problem in `tempQuestions` based on its ID.
    """
    try:
        problem_id = new_problem.get("id")
        result = temp_questions_collection.update_one(
            {'problems.id': problem_id},  # Match within the `problems` array by `id`
            {'$set': {'problems.$': new_problem}}  # Update the matched problem
        )
        
        if result.modified_count > 0:
            return JsonResponse({'message': 'Problem modified successfully!'}, status=200)
        else:
            return JsonResponse({'error': 'Problem not found or not modified'}, status=404)

    except Exception as e:
        print("Error modifying problem:", str(e))
        traceback.print_exc()
        return JsonResponse({'error': 'Failed to modify problem data'}, status=500)


def delete_problem_data(problem_id):
    """
    Deletes a problem from `tempQuestions` based on its ID within the `problems` array.
    """
    try:
        # Use `$pull` to remove the specific problem from the `problems` array
        result = temp_questions_collection.update_one(
            {},  # Assuming there's only one document; otherwise, specify a filter if needed
            {'$pull': {'problems': {'id': problem_id}}}
        )

        if result.modified_count > 0:
            return JsonResponse({'message': 'Problem deleted successfully!'}, status=200)
        else:
            return JsonResponse({'error': 'Problem not found for deletion'}, status=404)

    except Exception as e:
        print("Error deleting problem:", str(e))
        traceback.print_exc()
        return JsonResponse({'error': 'Failed to delete problem data'}, status=500)


@csrf_exempt
def save_problem(request):
    """
    Handles saving, modifying, and deleting problems in `tempQuestions`.
    """
    if request.method == 'GET':
        return fetch_Questions(request)

    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            new_problem = data.get("problems", [])[0]
            return save_problem_data(new_problem)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            print("An error occurred:", str(e))
            traceback.print_exc()
            return JsonResponse({'error': str(e)}, status=500)

    elif request.method == 'PUT':
        try:
            data = json.loads(request.body)
            new_problem = data.get("problems", [])[0]
            return modify_problem_data(new_problem)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            print("An error occurred:", str(e))
            traceback.print_exc()
            return JsonResponse({'error': str(e)}, status=500)

    elif request.method == 'DELETE':
        try:
            print("entered")
            data = json.loads(request.body)
            problem_id = data.get("id")
            print(problem_id)
            return delete_problem_data(problem_id)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            print("An error occurred:", str(e))
            traceback.print_exc()
            return JsonResponse({'error': str(e)}, status=500)

    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)